import java.util.ArrayList;
import java.util.Vector;

public class App {


    private static App instance = null;
    private DB mDatabase;


    protected App(){
        mDatabase = new DB();
    }

    public static App getInstance(){
        if (instance == null){
            instance = new App();
        }
        return instance;
    }


    public boolean login(String userName, String password){
        return mDatabase.login(userName, password);
    }

    public ArrayList<Product> searchItems(String productName){
        return mDatabase.searchItems(productName);
    }

    public void addNewProduct(Product product){
        mDatabase.addNewProduct(product);
    }

    public void deleteProduct(Product product){
        mDatabase.deleteProduct(product);
    }
    
}