import java.util.ArrayList;
import java.util.Vector;

public class ShoppingCart {

    private ArrayList<Product> mCart;
    private Integer mNumberOfItems;
    private boolean mDiscountApplied;

    public ShoppingCart(){
        mCart = new ArrayList<>();
        mNumberOfItems = 0;
        mDiscountApplied = false;
    }

    public ArrayList<Product> getCart() {
        return mCart;
    }

    public Integer getNumberOfItems() {
        return mNumberOfItems;
    }

    public boolean isDiscountApplied() {
        return mDiscountApplied;
    }

    public void addProduct(Product product){
        mCart.add(product);
    }
    
}