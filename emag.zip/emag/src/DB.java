import java.util.ArrayList;
import java.util.Vector;

public class DB {

      private ArrayList<Product> mProducts;
      private ArrayList<Buyer> mBuyers;

      public DB(){
          mProducts = new ArrayList<>();
          mBuyers = new ArrayList<>();
      }

      public boolean login(String userName, String password){
          for (Buyer buyer : mBuyers){
              if (userName.equals(buyer.getName()) && password.equals(buyer.getPassword())){
                  return true;
              }
          }
          return false;
      }

      public ArrayList<Product> searchItems(String productName){
          ArrayList<Product> productArrayList = new ArrayList<>();
          for (Product product : mProducts){
              if (productName.equals(product.getProductName())){
                  productArrayList.add(product);
              }
          }
          return productArrayList;
      }

      public void addNewProduct(Product product){
          mProducts.add(product);
      }

    public void deleteProduct(Product product){
        mProducts.remove(product);
    }



}