import java.util.Vector;

public class Admin extends User {

    private App mApplication;

    public Admin(){
        mApplication = App.getInstance();
    }

    public void addNewProduct(Product product){
        mApplication.addNewProduct(product);
    }

    public void deleteProduct(Product product){
        mApplication.deleteProduct(product);
    }

}