import javafx.application.Application;

import java.util.ArrayList;
import java.util.Vector;

public class Buyer extends User {

    private ShoppingCart mShoppingCart;
    private Favorite mFavoriteList;
    private App mApplication;
    private boolean mIsLogged;

    public Buyer(){
        mShoppingCart = new ShoppingCart();
        mApplication = App.getInstance();
        mFavoriteList = new Favorite();
        mIsLogged = false;
    }

    public void addProduct(Product product){
        mShoppingCart.addProduct(product);
    }

    public void addToFavorite(Product product){
        mFavoriteList.addToFavorite(product);
    }

    public void login(String userName, String password){
        mIsLogged = mApplication.login(userName, password);
    }

    public ArrayList<Product> searchProduct(String productName){
        return mApplication.searchItems(productName);
    }




}