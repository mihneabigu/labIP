import java.util.ArrayList;
import java.util.Vector;

public class Product {

      private ArrayList<Review> mReviews;
      private String mProductName;

      public Product(String productName){
            mReviews = new ArrayList<>();
            mProductName = productName;
      }


      public String getProductName() {
            return mProductName;
      }

      public ArrayList<Review> getReviews() {
            return mReviews;
      }
}