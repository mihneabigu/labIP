import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

public class Product {

      private HashMap<Buyer, Review> mReviews;
      private String mProductName;

      public Product(String productName){
            mReviews = new HashMap<>();
            mProductName = productName;
      }


      public String getProductName() {
            return mProductName;
      }

      public HashMap<Buyer, Review> getReviews() {
            return mReviews;
      }

      public void addReview(Buyer buyer, Review review){
            mReviews.put(buyer,review);
      }
}