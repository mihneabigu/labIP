public class Review {

    private String mReviewString;

    public Review(String reviewString){
        mReviewString = reviewString;
    }

    public String getReviewString() {
        return mReviewString;
    }
}