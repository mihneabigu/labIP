import java.util.ArrayList;

public class Favorite {

    private ArrayList<Product> mFavoriteList;

    public Favorite(){
        mFavoriteList = new ArrayList<>();
    }

    public ArrayList<Product> getFavoriteList() {
        return mFavoriteList;
    }

    public void addToFavorite(Product product){
        mFavoriteList.add(product);
    }
}
