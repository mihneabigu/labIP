import java.util.Vector;

public class Admin extends User {

    private App mApplication;
    private boolean mIsLogged;


    public Admin(String email, String ID, String name, String password){
        mApplication = App.getInstance();
        mIsLogged = false;
        setEmail(email);
        setID(ID);
        setName(name);
        setPassword(password);
    }

    public void login(String username, String password){
        mIsLogged = mApplication.login(username,password);
    }

    public void addNewProduct(Product product){
        mApplication.addNewProduct(product);
    }

    public void deleteProduct(Product product){
        mApplication.deleteProduct(product);
    }

}