import java.util.Vector;

public interface User {

    public Vector  myBuyer;
    public Vector  myBuyer;

}