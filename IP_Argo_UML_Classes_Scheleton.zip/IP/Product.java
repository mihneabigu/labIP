import java.util.Vector;

public class Product {

      public Vector  myReview;

}