import java.util.Vector;

public class Buyer implements User {

    public Vector  myShopping Cart;
    public Vector  myAPPLICATION;

}