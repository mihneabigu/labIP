import java.util.Vector;

public class Shopping Cart {

    public Vector  myBuyer;
    
}