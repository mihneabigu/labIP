import java.util.Vector;

public class Admin implements User {

    public Vector  myAPPLICATION;

}