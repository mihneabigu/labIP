import java.util.Vector;

public class DB {

      public Vector  myProduct;

}