import java.util.Vector;

public class APPLICATION {

    public Vector  myDB;
    
}